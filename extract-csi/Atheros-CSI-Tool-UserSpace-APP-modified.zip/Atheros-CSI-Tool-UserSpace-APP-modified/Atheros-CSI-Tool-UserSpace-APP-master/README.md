
The user-space applications for our Atheros-CSI-TOOL

Please visit our maintainance page http://pdcc.ntu.edu.sg/wands/Atheros/ for detailed infomration.

If you want more details on how to use this tool, please request the documentation http://pdcc.ntu.edu.sg/wands/Atheros/install/install_info.html.

Change Log, we now support one transmitter multiple receivers at the same time. One packet transmitted can be simultaneously received by multiple receivers and the CSI will be calculated accordingly. More detail can be found from our maintainance page. http://pdcc.ntu.edu.sg/wands/Atheros/
